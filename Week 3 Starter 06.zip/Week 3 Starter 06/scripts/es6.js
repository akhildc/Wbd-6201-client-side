console.log("es6.js loaded");

// #region ES6 Arrow Functions
// ES5
function printNameES5(name){
    return ('ES5 Traditional Function: Hello ' + name);
}

// ES6


// We can also write the above code without the return statement
// Called an implicit return





//#endregion ES6 Arrow Functions

//#region ES6 Function Parameters

// ES6 default parameters


// ES7 Default parameters in arrow functions (OOOOH!)

// New 'rest' parameters


//#endregion ES6 Function Parameters

//#region Cleaner Code

//#endregion Cleaner Code